To change your skin please follow the link:
http://dhtmlx.com/docs/products/skinBuilder/index.shtml#2180ada6c3